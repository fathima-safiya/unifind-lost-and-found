<?php
// Production configuration for InfinityFree hosting
$base_url = '';

$host     = 'sql302.infinityfree.com';
$dbname   = 'if0_42903501_unifind';
$username = 'if0_42903501';
$password = 'PXyN6VNuxX9M';
?>
